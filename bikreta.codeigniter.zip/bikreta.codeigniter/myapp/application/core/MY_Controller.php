<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
	
	public $guzzle;
	public $token = '';

	private $_username = '';
	private $_password = '';

	private $_BASE_URL = 'https://mcstaging.sastodeal.com/rest/V1/';

	public function __construct(){

		parent::__construct();

		$this->load->library('guzzle');
		$this->load->helper('url');
		
		$this->guzzle     = new GuzzleHttp\Client();

	}

	private function _generateToken(){

		$url = $this->_BASE_URL.'integration/admin/token';
	}

	public function frontView($view_file,$data = ''){
		
		$this->load->view('include/header', $data);
		$this->load->view($view_file, $data);
		$this->load->view('include/footer', $data);

	}

	protected function _postFormCurl( $url, $data, $type = 'POST' ){

		$url = $this->_BASE_URL.$url;

		$ch = curl_init($url);

		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Content-Length: " . strlen(json_encode($data))));
		 
		$token = curl_exec($ch);

		if(!$token){
		    die('Error: "' . curl_error($curl) . '" - Code: ' . curl_errno($curl));
		}

		return $token;
	}

	function getOtherQuery(){
		$ch = curl_init("http://magento.m2/index.php/rest/V1/customers/1");
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . json_decode($token)));
		 
		$result = curl_exec($ch);
		 
		var_dump($result);
	}

	protected function _postQuery( $url, $data = [] , $type = 'POST' ){

			$url = $this->_BASE_URL.$url;
	
		  #guzzle
		  try {
		    # guzzle post request example with form parameter
		    $response = $this->guzzle->request( 
		    			$type, 
						$url, 
						$data
			);

		    print_r( $response );
			die();

		    #guzzle repose for future use
		   // echo $response->getStatusCode(); // 200
		    //echo $response->getReasonPhrase(); // OK
		    //echo $response->getProtocolVersion(); // 1.1
		    echo $response->getBody();
		    
		  } catch (GuzzleHttp\Exception\BadResponseException $e) {
		    #guzzle repose for future use
		    $response = $e->getResponse();
		    $responseBodyAsString = $response->getBody()->getContents();
		    print_r($responseBodyAsString);
		  }
	}

}