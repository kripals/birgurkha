<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller {

	public function index(){

		$this->frontView('login');
	}

	public function check(){

		$username = $this->input->post('username');
		$password = $this->input->post('password');

		if( $username AND $password ) {

			$data = array(
					'username' => $username,
					'password' => $password,
			);

			$resp = $this->_postFormCurl('integration/admin/token', $data );

			print_r( $resp );
			die();

		}
	}
}
